import sqlite3
conn = sqlite3.connect('instance/bank.db')
conn.row_factory = sqlite3.Row
cur = conn.cursor()

cur.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")
tables = [r[0] for r in cur.fetchall()]
print('Tables:', tables)

cur.execute("SELECT username, full_name FROM admin")
print('Admin:', [dict(r) for r in cur.fetchall()])

cur.execute("SELECT branch_name, ifsc_code FROM branch")
print('Branches:', [dict(r) for r in cur.fetchall()])

cur.execute("SELECT first_name, last_name FROM customer")
print('Customers:', [dict(r) for r in cur.fetchall()])

cur.execute("SELECT account_number, balance, status FROM account")
print('Accounts:', [dict(r) for r in cur.fetchall()])

cur.execute("SELECT transaction_type, amount FROM transactions")
print('Transactions:', [dict(r) for r in cur.fetchall()])

conn.close()
print("Verification complete!")

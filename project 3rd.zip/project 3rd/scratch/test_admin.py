import urllib.request, urllib.parse, urllib.error, http.cookiejar

jar = http.cookiejar.CookieJar()
opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))

BASE = "http://127.0.0.1:5000"

def post(path, data):
    encoded = urllib.parse.urlencode(data).encode()
    req = urllib.request.Request(BASE + path, data=encoded, method="POST")
    req.add_header("Content-Type", "application/x-www-form-urlencoded")
    try:
        with opener.open(req, timeout=5) as r:
            body = r.read().decode("utf-8", errors="ignore")
            return r.status, r.url, body
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="ignore")
        return e.code, path, body

def get(path):
    req = urllib.request.Request(BASE + path)
    try:
        with opener.open(req, timeout=5) as r:
            body = r.read().decode("utf-8", errors="ignore")
            return r.status, r.url, body
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="ignore")
        return e.code, path, body

def check(label, code, url, body):
    err = "Server Error" if ("Internal Server Error" in body or "Traceback" in body) else ""
    status = "FAIL" if err or code >= 400 else "OK"
    print(f"{status}  [{code}] {label} => {url.replace(BASE,'')} {err}")
    if err:
        print("    ", body[:400])

# Login as admin
post("/admin/login", {"username": "admin", "password": "admin123"})

print("=== Admin Pages ===")
for label, path in [
    ("Dashboard", "/admin/dashboard"),
    ("Customers", "/admin/customers"),
    ("Accounts",  "/admin/accounts"),
    ("Transactions", "/admin/transactions"),
    ("Loans",     "/admin/loans"),
    ("Deposits",  "/admin/deposits"),
    ("Branches",  "/admin/branches"),
]:
    code, url, body = get(path)
    check(label, code, url, body)

print("\nAdmin tests done!")

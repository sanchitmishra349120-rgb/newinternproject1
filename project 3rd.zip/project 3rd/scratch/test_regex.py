import re

with open('bank_management_system_database.sql', 'r', encoding='utf-8') as f:
    sql_content = f.read()

# Try the translations
# 1. Remove database level operations
sql_content = re.sub(r'(?i)DROP DATABASE IF EXISTS[^;]+;', '', sql_content)
sql_content = re.sub(r'(?i)CREATE DATABASE[^;]+;', '', sql_content)
sql_content = re.sub(r'(?i)USE[^;]+;', '', sql_content)

print("--- After removing DB statements ---")
print(sql_content[:400])

# Translate primary keys
sql_content = re.sub(r'(?i)\b(?:BIG)?INT\s+AUTO_INCREMENT\s+PRIMARY\s+KEY\b', 'INTEGER PRIMARY KEY AUTOINCREMENT', sql_content)

# Translate ENUMS
sql_content = re.sub(r'(?i)ENUM\([^)]+\)', 'VARCHAR(50)', sql_content)

print("\n--- After translations ---")
lines = sql_content.split('\n')
for i in range(30, 80):
    if i < len(lines):
        print(f"{i+1}: {lines[i]}")

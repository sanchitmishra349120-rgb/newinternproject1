import urllib.request, urllib.parse, urllib.error, http.cookiejar

jar = http.cookiejar.CookieJar()
opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))

BASE = "http://127.0.0.1:5000"

def post(path, data):
    encoded = urllib.parse.urlencode(data).encode()
    req = urllib.request.Request(BASE + path, data=encoded, method="POST")
    req.add_header("Content-Type", "application/x-www-form-urlencoded")
    try:
        with opener.open(req, timeout=5) as r:
            body = r.read().decode("utf-8", errors="ignore")
            return r.status, r.url, body
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="ignore")
        return e.code, path, body

def get(path):
    req = urllib.request.Request(BASE + path)
    try:
        with opener.open(req, timeout=5) as r:
            body = r.read().decode("utf-8", errors="ignore")
            return r.status, r.url, body
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="ignore")
        return e.code, path, body

def check(label, code, url, body):
    err = "Server Error" if ("Internal Server Error" in body or "Traceback" in body) else ""
    status = "FAIL" if err or code >= 400 else "OK"
    print(f"{status}  [{code}] {label} => {url.replace(BASE,'')} {err}")
    if err:
        # print first 300 chars of body for debug
        print("    ", body[:300])

# ── Admin login ──────────────────────────────────────────────────────────────
print("\n=== Admin Login ===")
code, url, body = post("/admin/login", {"username": "admin", "password": "admin123"})
check("Admin Login POST", code, url, body)

# Expecting redirect to /admin/dashboard
code, url, body = get("/admin/dashboard")
check("Admin Dashboard GET", code, url, body)

# ── Customer login ───────────────────────────────────────────────────────────
print("\n=== Customer Login ===")
# First logout admin
get("/logout")
code, url, body = post("/customer/login", {"account_number": "100000000001", "password": "rahul123"})
check("Customer Login POST", code, url, body)

# Check customer dashboard
code, url, body = get("/customer/dashboard")
check("Customer Dashboard GET", code, url, body)

# Check customer profile
code, url, body = get("/customer/profile")
check("Customer Profile GET", code, url, body)

# Check deposit-withdraw page
code, url, body = get("/customer/deposit-withdraw")
check("Deposit/Withdraw GET", code, url, body)

# Check transfer page
code, url, body = get("/customer/transfer")
check("Transfer GET", code, url, body)

# Check loans page
code, url, body = get("/customer/loans")
check("Loans GET", code, url, body)

# Check FD page
code, url, body = get("/customer/fd")
check("FD GET", code, url, body)

# Check RD page
code, url, body = get("/customer/rd")
check("RD GET", code, url, body)

# Check transactions page
code, url, body = get("/customer/transactions")
check("Transactions GET", code, url, body)

# Check beneficiaries page
code, url, body = get("/customer/beneficiaries")
check("Beneficiaries GET", code, url, body)

# Check branches page
code, url, body = get("/customer/branches")
check("Branches GET", code, url, body)

print("\nAll tests done!")

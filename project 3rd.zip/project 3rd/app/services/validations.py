import re
from datetime import datetime, date

class Validator:
    @staticmethod
    def validate_name(name: str) -> bool:
        """Allows alphabets and spaces only. Length: 2 to 50 characters."""
        pattern = r"^[A-Za-z ]{2,50}$"
        return bool(re.fullmatch(pattern, name.strip()))

    @staticmethod
    def validate_mobile(mobile: str) -> bool:
        """Indian mobile number validation (starts with 6-9, contains 10 digits)."""
        pattern = r"^[6-9][0-9]{9}$"
        return bool(re.fullmatch(pattern, mobile))

    @staticmethod
    def validate_email(email: str) -> bool:
        """Standard email validation."""
        pattern = r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[A-Za-z]{2,}$"
        return bool(re.fullmatch(pattern, email))

    @staticmethod
    def validate_aadhaar(aadhaar: str) -> bool:
        """Aadhaar must contain exactly 12 digits."""
        pattern = r"^\d{12}$"
        return bool(re.fullmatch(pattern, aadhaar))

    @staticmethod
    def validate_pan(pan: str) -> bool:
        """PAN Format: ABCDE1234F"""
        pattern = r"^[A-Z]{5}[0-9]{4}[A-Z]{1}$"
        return bool(re.fullmatch(pattern, pan.upper()))

    @staticmethod
    def validate_pincode(pincode: str) -> bool:
        """Indian PIN code."""
        pattern = r"^[1-9][0-9]{5}$"
        return bool(re.fullmatch(pattern, pincode))

    @staticmethod
    def validate_password(password: str) -> bool:
        """
        Password Rules:
        Minimum 8 characters, at least one uppercase, one lowercase, one number, one special character.
        """
        pattern = (
            r"^(?=.*[a-z])"
            r"(?=.*[A-Z])"
            r"(?=.*\d)"
            r"(?=.*[@$!%*?&])"
            r"[A-Za-z\d@$!%*?&]{8,}$"
        )
        return bool(re.fullmatch(pattern, password))

    @staticmethod
    def validate_atm_pin(pin: str) -> bool:
        """ATM PIN must contain exactly 4 digits."""
        pattern = r"^\d{4}$"
        return bool(re.fullmatch(pattern, pin))

    @staticmethod
    def validate_account_number(account_number: str) -> bool:
        """Account number: 10 to 18 digits."""
        pattern = r"^\d{10,18}$"
        return bool(re.fullmatch(pattern, account_number))

    @staticmethod
    def validate_ifsc(ifsc: str) -> bool:
        """IFSC Example: SBIN0001234"""
        pattern = r"^[A-Z]{4}0[A-Z0-9]{6}$"
        return bool(re.fullmatch(pattern, ifsc.upper()))

    @staticmethod
    def validate_date(date_string: str) -> bool:
        """Format: YYYY-MM-DD"""
        try:
            datetime.strptime(date_string, "%Y-%m-%d")
            return True
        except ValueError:
            return False

    @staticmethod
    def validate_dob(date_string: str) -> bool:
        """Customer must be at least 18 years old."""
        try:
            dob = datetime.strptime(date_string, "%Y-%m-%d").date()
            today = date.today()
            age = today.year - dob.year - ((today.month, today.day) < (dob.month, dob.day))
            return age >= 18
        except ValueError:
            return False

    @staticmethod
    def validate_gender(gender: str) -> bool:
        return gender.capitalize() in ("Male", "Female", "Other")

    @staticmethod
    def validate_amount(amount) -> bool:
        """Amount must be greater than zero."""
        try:
            amount = float(amount)
            return amount > 0
        except ValueError:
            return False

    @staticmethod
    def validate_interest(rate) -> bool:
        try:
            rate = float(rate)
            return 0 <= rate <= 100
        except ValueError:
            return False

    @staticmethod
    def validate_tenure(months) -> bool:
        try:
            months = int(months)
            return months > 0
        except ValueError:
            return False

    @staticmethod
    def validate_transaction_type(transaction_type: str) -> bool:
        return transaction_type in ("Deposit", "Withdraw", "Transfer", "Loan", "FD", "RD")

    @staticmethod
    def validate_account_type(account_type: str) -> bool:
        return account_type.capitalize() in ("Savings", "Current")

    @staticmethod
    def validate_branch_code(branch_code: str) -> bool:
        pattern = r"^B\d{3}$"
        return bool(re.fullmatch(pattern, branch_code.upper()))

    @staticmethod
    def is_not_empty(value: str) -> bool:
        return bool(value.strip())

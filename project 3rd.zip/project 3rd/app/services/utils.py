import random
import uuid
from datetime import datetime, date

class Utils:
    @staticmethod
    def current_date():
        return datetime.now().strftime("%Y-%m-%d")

    @staticmethod
    def current_time():
        return datetime.now().strftime("%H:%M:%S")

    @staticmethod
    def current_datetime():
        return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    @staticmethod
    def format_currency(amount):
        """Format currency in Indian Rupees style (₹12,500.50)"""
        try:
            val = float(amount)
            return f"₹{val:,.2f}"
        except (ValueError, TypeError):
            return "₹0.00"

    @staticmethod
    def generate_account_number():
        """Generates a random 12-digit account number."""
        return random.randint(100000000000, 999999999999)

    @staticmethod
    def generate_transaction_reference():
        timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
        unique = uuid.uuid4().hex[:6].upper()
        return f"TXN-{timestamp}-{unique}"

    @staticmethod
    def generate_loan_number():
        return "LN" + datetime.now().strftime("%Y%m%d%H%M%S")

    @staticmethod
    def generate_fd_number():
        return "FD" + datetime.now().strftime("%Y%m%d%H%M%S")

    @staticmethod
    def generate_rd_number():
        return "RD" + datetime.now().strftime("%Y%m%d%H%M%S")

    @staticmethod
    def generate_receipt_number():
        return "RCPT-" + uuid.uuid4().hex[:10].upper()

    @staticmethod
    def calculate_fd_maturity(principal, rate, months):
        years = months / 12
        maturity = principal + ((principal * rate * years) / 100)
        return round(maturity, 2)

    @staticmethod
    def calculate_rd_maturity(monthly_amount, rate, months):
        total = monthly_amount * months
        years = months / 12
        interest = (total * rate * years) / 100
        return round(total + interest, 2)

    @staticmethod
    def calculate_emi(principal, annual_rate, months):
        monthly_rate = annual_rate / (12 * 100)
        if monthly_rate == 0:
            return round(principal / months, 2)
        emi = (principal * monthly_rate * ((1 + monthly_rate) ** months)) / (((1 + monthly_rate) ** months) - 1)
        return round(emi, 2)

    @staticmethod
    def mask_aadhaar(aadhaar):
        return "XXXXXXXX" + str(aadhaar)[-4:]

    @staticmethod
    def mask_mobile(mobile):
        return "XXXXXX" + str(mobile)[-4:]

    @staticmethod
    def mask_account(account_number):
        account_number = str(account_number)
        return "XXXXXXXX" + account_number[-4:]

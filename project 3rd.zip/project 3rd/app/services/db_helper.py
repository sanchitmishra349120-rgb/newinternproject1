import os
import sqlite3
from datetime import datetime

class Database:
    """
    Unified Database wrapper that supports MySQL and SQLite.
    Translates query placeholders and standard functions dynamically for SQLite.
    """
    def __init__(self):
        self.connection = None
        self.cursor = None
        self.db_type = None
        self.sqlite_path = None
        self.mysql_config = {}

    def init_app(self, app):
        """Initialize connection parameters from Flask app config."""
        self.db_type = app.config.get("DB_TYPE", "sqlite").lower()
        self.sqlite_path = app.config.get("SQLITE_DB_PATH")
        
        self.mysql_config = {
            "host": app.config.get("MYSQL_HOST"),
            "port": app.config.get("MYSQL_PORT"),
            "user": app.config.get("MYSQL_USER"),
            "password": app.config.get("MYSQL_PASSWORD"),
            "database": app.config.get("MYSQL_DATABASE")
        }
        
        # Ensure instance directory exists if using SQLite
        if self.db_type == "sqlite" and self.sqlite_path:
            os.makedirs(os.path.dirname(self.sqlite_path), exist_ok=True)

    def connect(self):
        """Establish database connection."""
        if self.connection:
            return True
            
        try:
            if self.db_type == "mysql":
                try:
                    import mysql.connector
                    self.connection = mysql.connector.connect(**self.mysql_config)
                    if self.connection.is_connected():
                        self.cursor = self.connection.cursor(dictionary=True)
                        return True
                except Exception as mysql_err:
                    print(f"MySQL connection failed: {mysql_err}. Falling back to SQLite.")
                    self.db_type = "sqlite"

            if self.db_type == "sqlite":
                self.connection = sqlite3.connect(self.sqlite_path, check_same_thread=False)
                self.connection.row_factory = sqlite3.Row
                self.cursor = self.connection.cursor()
                return True
                
        except Exception as e:
            print(f"Database Connection Error: {e}")
            
        return False

    def disconnect(self):
        """Close connection and cursor."""
        try:
            if self.cursor:
                self.cursor.close()
            if self.connection:
                self.connection.close()
        except Exception as e:
            print(f"Disconnect error: {e}")
        finally:
            self.connection = None
            self.cursor = None

    def _translate_query(self, query):
        """Helper to translate MySQL query queries to SQLite format."""
        if self.db_type == "sqlite" and query:
            # Replace MySQL placeholders with SQLite placeholders
            query = query.replace("%s", "?")
            # Replace date functions
            query = query.replace("NOW()", "CURRENT_TIMESTAMP")
            query = query.replace("CURDATE()", "CURRENT_DATE")
        return query

    def execute(self, query, values=None):
        """Execute INSERT/UPDATE/DELETE query. Returns True if successful."""
        self.connect()
        translated_query = self._translate_query(query)
        try:
            if values:
                # Handle single element tuple formatting issues
                if not isinstance(values, (list, tuple)):
                    values = (values,)
                self.cursor.execute(translated_query, values)
            else:
                self.cursor.execute(translated_query)
            self.connection.commit()
            return True
        except Exception as e:
            print(f"Database execution error on: {translated_query}\nError: {e}")
            if self.connection:
                self.connection.rollback()
            return False

    def fetch_one(self, query, values=None):
        """Fetch a single row as a dictionary."""
        self.connect()
        translated_query = self._translate_query(query)
        try:
            if values:
                if not isinstance(values, (list, tuple)):
                    values = (values,)
                self.cursor.execute(translated_query, values)
            else:
                self.cursor.execute(translated_query)
            
            row = self.cursor.fetchone()
            if row is None:
                return None
                
            if self.db_type == "sqlite":
                return dict(row)
            return row
        except Exception as e:
            print(f"Database fetch_one error on: {translated_query}\nError: {e}")
            return None

    def fetch_all(self, query, values=None):
        """Fetch all matching rows as a list of dictionaries."""
        self.connect()
        translated_query = self._translate_query(query)
        try:
            if values:
                if not isinstance(values, (list, tuple)):
                    values = (values,)
                self.cursor.execute(translated_query, values)
            else:
                self.cursor.execute(translated_query)
            
            rows = self.cursor.fetchall()
            if self.db_type == "sqlite":
                return [dict(r) for r in rows]
            return rows
        except Exception as e:
            print(f"Database fetch_all error on: {translated_query}\nError: {e}")
            return []

    def record_exists(self, query, values=None):
        """Check if any records match the query."""
        row = self.fetch_one(query, values)
        return row is not None

    def last_insert_id(self):
        """Return the ID of the last inserted row."""
        if self.db_type == "sqlite":
            return self.cursor.lastrowid
        else:
            return self.cursor.lastrowid

    def begin(self):
        """Begin SQL transaction."""
        self.connect()
        if self.db_type == "mysql":
            self.connection.start_transaction()
        # For sqlite3, transactions are started automatically on first modification command.

    def commit(self):
        """Commit SQL transaction."""
        if self.connection:
            self.connection.commit()

    def rollback(self):
        """Rollback SQL transaction."""
        if self.connection:
            self.connection.rollback()

db = Database()

# App extensions definition file
from app.services.db_helper import db

# This file can be used to export external components (like socketio, mail, etc. in future)

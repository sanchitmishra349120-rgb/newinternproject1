from app.services.db_helper import db

class BeneficiaryModel:
    @staticmethod
    def exists(account_number, beneficiary_account):
        query = """
        SELECT * FROM beneficiary 
        WHERE account_number = %s AND beneficiary_account = %s
        """
        return db.fetch_one(query, (account_number, beneficiary_account))

    @staticmethod
    def add(account_number, beneficiary_account, beneficiary_name):
        query = """
        INSERT INTO beneficiary (account_number, beneficiary_account, beneficiary_name, added_date)
        VALUES (%s, %s, %s, CURRENT_DATE)
        """
        return db.execute(query, (account_number, beneficiary_account, beneficiary_name))

    @staticmethod
    def delete(beneficiary_id):
        return db.execute("DELETE FROM beneficiary WHERE beneficiary_id = %s", (beneficiary_id,))

    @staticmethod
    def get_by_account(account_number):
        query = """
        SELECT * FROM beneficiary 
        WHERE account_number = %s 
        ORDER BY beneficiary_name ASC
        """
        return db.fetch_all(query, (account_number,))

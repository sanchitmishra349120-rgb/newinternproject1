from app.services.db_helper import db

class AccountModel:
    @staticmethod
    def get_by_number(account_number):
        return db.fetch_one("SELECT * FROM account WHERE account_number = %s", (account_number,))

    @staticmethod
    def get_by_customer_id(customer_id):
        # A customer can have multiple accounts (e.g., Savings and Current)
        return db.fetch_all("SELECT * FROM account WHERE customer_id = %s", (customer_id,))

    @staticmethod
    def get_details(account_number):
        """Fetch account details with customer and branch details."""
        query = """
        SELECT a.*, c.first_name, c.last_name, c.email, c.mobile, c.aadhaar, c.pan,
               b.branch_name, b.branch_code, b.ifsc_code
        FROM account a
        JOIN customer c ON a.customer_id = c.customer_id
        JOIN branch b ON a.branch_id = b.branch_id
        WHERE a.account_number = %s
        """
        return db.fetch_one(query, (account_number,))

    @staticmethod
    def create(account_number, customer_id, branch_id, account_type, balance, login_password, atm_pin=None):
        query = """
        INSERT INTO account 
        (account_number, customer_id, branch_id, account_type, balance, opening_date, status, atm_pin, login_password)
        VALUES (%s, %s, %s, %s, %s, CURRENT_DATE, 'Active', %s, %s)
        """
        return db.execute(query, (account_number, customer_id, branch_id, account_type, balance, atm_pin, login_password))

    @staticmethod
    def update_balance(account_number, new_balance):
        return db.execute("UPDATE account SET balance = %s WHERE account_number = %s", (new_balance, account_number))

    @staticmethod
    def update_status(account_number, status):
        return db.execute("UPDATE account SET status = %s WHERE account_number = %s", (status, account_number))

    @staticmethod
    def get_all():
        query = """
        SELECT a.*, c.first_name, c.last_name, b.branch_name
        FROM account a
        JOIN customer c ON a.customer_id = c.customer_id
        JOIN branch b ON a.branch_id = b.branch_id
        ORDER BY a.opening_date DESC
        """
        return db.fetch_all(query)

    @staticmethod
    def search(search_query):
        query = """
        SELECT a.*, c.first_name, c.last_name, b.branch_name
        FROM account a
        JOIN customer c ON a.customer_id = c.customer_id
        JOIN branch b ON a.branch_id = b.branch_id
        WHERE a.account_number LIKE %s OR c.first_name LIKE %s OR c.last_name LIKE %s
        """
        param = f"%{search_query}%"
        return db.fetch_all(query, (param, param, param))

    @staticmethod
    def get_stats():
        total = db.fetch_one("SELECT COUNT(*) as count, SUM(balance) as total_balance FROM account")
        type_stats = db.fetch_all("SELECT account_type, COUNT(*) as count FROM account GROUP BY account_type")
        status_stats = db.fetch_all("SELECT status, COUNT(*) as count FROM account GROUP BY status")
        return {
            "total": total["count"] if total else 0,
            "total_balance": float(total["total_balance"]) if total and total["total_balance"] else 0.0,
            "types": {row["account_type"]: row["count"] for row in type_stats} if type_stats else {},
            "status": {row["status"]: row["count"] for row in status_stats} if status_stats else {}
        }

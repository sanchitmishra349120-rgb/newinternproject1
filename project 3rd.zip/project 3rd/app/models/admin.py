from app.services.db_helper import db

class AdminModel:
    @staticmethod
    def get_by_username(username):
        return db.fetch_one("SELECT * FROM admin WHERE username = %s", (username,))

    @staticmethod
    def get_by_id(admin_id):
        return db.fetch_one("SELECT * FROM admin WHERE admin_id = %s", (admin_id,))

    @staticmethod
    def create(username, password, full_name, mobile, email):
        query = """
        INSERT INTO admin (username, password, full_name, mobile, email)
        VALUES (%s, %s, %s, %s, %s)
        """
        return db.execute(query, (username, password, full_name, mobile, email))

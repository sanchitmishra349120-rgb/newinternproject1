from app.services.db_helper import db

class BranchModel:
    @staticmethod
    def get_all():
        return db.fetch_all("SELECT * FROM branch ORDER BY branch_name ASC")

    @staticmethod
    def get_by_id(branch_id):
        return db.fetch_one("SELECT * FROM branch WHERE branch_id = %s", (branch_id,))

    @staticmethod
    def get_by_code(branch_code):
        return db.fetch_one("SELECT * FROM branch WHERE branch_code = %s", (branch_code,))

    @staticmethod
    def create(branch_name, branch_code, ifsc_code, address, city, state, pincode):
        query = """
        INSERT INTO branch (branch_name, branch_code, ifsc_code, address, city, state, pincode)
        VALUES (%s, %s, %s, %s, %s, %s, %s)
        """
        return db.execute(query, (branch_name, branch_code.upper(), ifsc_code.upper(), address, city, state, pincode))

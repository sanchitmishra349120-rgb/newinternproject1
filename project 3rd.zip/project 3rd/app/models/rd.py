from app.services.db_helper import db

class RecurringDepositModel:
    @staticmethod
    def create(account_number, monthly_amount, interest_rate, tenure_months, maturity_date, maturity_amount):
        query = """
        INSERT INTO recurring_deposit 
        (account_number, monthly_amount, interest_rate, tenure_months, start_date, maturity_date, maturity_amount)
        VALUES (%s, %s, %s, %s, CURRENT_DATE, %s, %s)
        """
        return db.execute(query, (account_number, monthly_amount, interest_rate, tenure_months, maturity_date, maturity_amount))

    @staticmethod
    def get_by_id(rd_id):
        return db.fetch_one("SELECT * FROM recurring_deposit WHERE rd_id = %s", (rd_id,))

    @staticmethod
    def get_by_account(account_number):
        return db.fetch_all("SELECT * FROM recurring_deposit WHERE account_number = %s ORDER BY start_date DESC", (account_number,))

    @staticmethod
    def get_all():
        query = """
        SELECT rd.*, c.first_name, c.last_name
        FROM recurring_deposit rd
        JOIN account a ON rd.account_number = a.account_number
        JOIN customer c ON a.customer_id = c.customer_id
        ORDER BY rd.start_date DESC
        """
        return db.fetch_all(query)

    @staticmethod
    def get_stats():
        stats = db.fetch_one("SELECT COUNT(*) as count, SUM(monthly_amount) as total_monthly FROM recurring_deposit")
        return {
            "total": stats["count"] if stats else 0,
            "total_monthly": float(stats["total_monthly"]) if stats and stats["total_monthly"] else 0.0
        }

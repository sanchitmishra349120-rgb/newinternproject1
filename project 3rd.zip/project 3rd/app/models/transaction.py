from app.services.db_helper import db

class TransactionModel:
    @staticmethod
    def record(account_number, transaction_type, amount, balance_after, description):
        query = """
        INSERT INTO transactions (account_number, transaction_type, amount, balance_after, description, transaction_time)
        VALUES (%s, %s, %s, %s, %s, CURRENT_TIMESTAMP)
        """
        return db.execute(query, (account_number, transaction_type, amount, balance_after, description))

    @staticmethod
    def get_by_account(account_number):
        query = """
        SELECT * FROM transactions 
        WHERE account_number = %s 
        ORDER BY transaction_time DESC
        """
        return db.fetch_all(query, (account_number,))

    @staticmethod
    def get_all():
        query = """
        SELECT t.*, c.first_name, c.last_name
        FROM transactions t
        JOIN account a ON t.account_number = a.account_number
        JOIN customer c ON a.customer_id = c.customer_id
        ORDER BY t.transaction_time DESC
        """
        return db.fetch_all(query)

    @staticmethod
    def get_recent(limit=10):
        query = """
        SELECT t.*, c.first_name, c.last_name
        FROM transactions t
        JOIN account a ON t.account_number = a.account_number
        JOIN customer c ON a.customer_id = c.customer_id
        ORDER BY t.transaction_time DESC
        LIMIT %s
        """
        return db.fetch_all(query, (limit,))

    @staticmethod
    def get_recent_by_account(account_number, limit=5):
        query = """
        SELECT * FROM transactions 
        WHERE account_number = %s 
        ORDER BY transaction_time DESC 
        LIMIT %s
        """
        return db.fetch_all(query, (account_number, limit))

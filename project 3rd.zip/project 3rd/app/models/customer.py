from app.services.db_helper import db

class CustomerModel:
    @staticmethod
    def exists(customer_id):
        return db.fetch_one("SELECT * FROM customer WHERE customer_id = %s", (customer_id,))

    @staticmethod
    def get_by_id(customer_id):
        return db.fetch_one("SELECT * FROM customer WHERE customer_id = %s", (customer_id,))

    @staticmethod
    def get_by_email(email):
        return db.fetch_one("SELECT * FROM customer WHERE email = %s", (email,))

    @staticmethod
    def get_by_mobile(mobile):
        return db.fetch_one("SELECT * FROM customer WHERE mobile = %s", (mobile,))

    @staticmethod
    def get_by_aadhaar(aadhaar):
        return db.fetch_one("SELECT * FROM customer WHERE aadhaar = %s", (aadhaar,))

    @staticmethod
    def get_by_pan(pan):
        return db.fetch_one("SELECT * FROM customer WHERE pan = %s", (pan,))

    @staticmethod
    def create(first_name, last_name, gender, dob, mobile, email, aadhaar, pan, address, city, state, pincode):
        query = """
        INSERT INTO customer 
        (first_name, last_name, gender, dob, mobile, email, aadhaar, pan, address, city, state, pincode)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """
        success = db.execute(query, (first_name, last_name, gender, dob, mobile, email, aadhaar, pan, address, city, state, pincode))
        if success:
            return db.last_insert_id()
        return None

    @staticmethod
    def update(customer_id, first_name, last_name, gender, dob, address, city, state, pincode):
        query = """
        UPDATE customer 
        SET first_name = %s, last_name = %s, gender = %s, dob = %s, address = %s, city = %s, state = %s, pincode = %s
        WHERE customer_id = %s
        """
        return db.execute(query, (first_name, last_name, gender, dob, address, city, state, pincode, customer_id))

    @staticmethod
    def get_all():
        return db.fetch_all("SELECT * FROM customer ORDER BY customer_id DESC")

    @staticmethod
    def search(search_query):
        sql = """
        SELECT * FROM customer 
        WHERE first_name LIKE %s OR last_name LIKE %s OR email LIKE %s OR mobile LIKE %s
        """
        param = f"%{search_query}%"
        return db.fetch_all(sql, (param, param, param, param))

    @staticmethod
    def get_stats():
        total = db.fetch_one("SELECT COUNT(*) as count FROM customer")
        gender_stats = db.fetch_all("SELECT gender, COUNT(*) as count FROM customer GROUP BY gender")
        return {
            "total": total["count"] if total else 0,
            "gender": {row["gender"]: row["count"] for row in gender_stats} if gender_stats else {}
        }

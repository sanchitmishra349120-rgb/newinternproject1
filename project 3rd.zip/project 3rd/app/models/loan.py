from app.services.db_helper import db

class LoanModel:
    @staticmethod
    def apply(account_number, loan_type, amount, interest_rate, tenure_months):
        query = """
        INSERT INTO loan (account_number, loan_type, amount, interest_rate, tenure_months, status, applied_date)
        VALUES (%s, %s, %s, %s, %s, 'Pending', CURRENT_DATE)
        """
        return db.execute(query, (account_number, loan_type, amount, interest_rate, tenure_months))

    @staticmethod
    def get_by_id(loan_id):
        return db.fetch_one("SELECT * FROM loan WHERE loan_id = %s", (loan_id,))

    @staticmethod
    def get_by_account(account_number):
        return db.fetch_all("SELECT * FROM loan WHERE account_number = %s ORDER BY applied_date DESC", (account_number,))

    @staticmethod
    def get_all():
        query = """
        SELECT l.*, c.first_name, c.last_name
        FROM loan l
        JOIN account a ON l.account_number = a.account_number
        JOIN customer c ON a.customer_id = c.customer_id
        ORDER BY l.applied_date DESC
        """
        return db.fetch_all(query)

    @staticmethod
    def update_status(loan_id, status):
        return db.execute("UPDATE loan SET status = %s WHERE loan_id = %s", (status, loan_id))

    @staticmethod
    def get_stats():
        total = db.fetch_one("SELECT COUNT(*) as count, SUM(amount) as total_amount FROM loan")
        status_stats = db.fetch_all("SELECT status, COUNT(*) as count FROM loan GROUP BY status")
        return {
            "total": total["count"] if total else 0,
            "total_amount": float(total["total_amount"]) if total and total["total_amount"] else 0.0,
            "status": {row["status"]: row["count"] for row in status_stats} if status_stats else {}
        }

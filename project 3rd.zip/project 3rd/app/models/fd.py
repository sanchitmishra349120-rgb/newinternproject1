from app.services.db_helper import db

class FixedDepositModel:
    @staticmethod
    def create(account_number, amount, interest_rate, tenure_months, maturity_date, maturity_amount):
        query = """
        INSERT INTO fixed_deposit 
        (account_number, amount, interest_rate, tenure_months, start_date, maturity_date, maturity_amount)
        VALUES (%s, %s, %s, %s, CURRENT_DATE, %s, %s)
        """
        return db.execute(query, (account_number, amount, interest_rate, tenure_months, maturity_date, maturity_amount))

    @staticmethod
    def get_by_id(fd_id):
        return db.fetch_one("SELECT * FROM fixed_deposit WHERE fd_id = %s", (fd_id,))

    @staticmethod
    def get_by_account(account_number):
        return db.fetch_all("SELECT * FROM fixed_deposit WHERE account_number = %s ORDER BY start_date DESC", (account_number,))

    @staticmethod
    def get_all():
        query = """
        SELECT fd.*, c.first_name, c.last_name
        FROM fixed_deposit fd
        JOIN account a ON fd.account_number = a.account_number
        JOIN customer c ON a.customer_id = c.customer_id
        ORDER BY fd.start_date DESC
        """
        return db.fetch_all(query)

    @staticmethod
    def get_stats():
        stats = db.fetch_one("SELECT COUNT(*) as count, SUM(amount) as total_amount FROM fixed_deposit")
        return {
            "total": stats["count"] if stats else 0,
            "total_amount": float(stats["total_amount"]) if stats and stats["total_amount"] else 0.0
        }

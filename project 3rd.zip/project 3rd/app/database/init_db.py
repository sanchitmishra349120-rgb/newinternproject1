import os
import sqlite3
import re

def init_db(schema_path, db_path):
    print(f"Initializing database from {schema_path} to {db_path}...")

    os.makedirs(os.path.dirname(os.path.abspath(db_path)), exist_ok=True)

    with open(schema_path, 'r', encoding='utf-8') as f:
        sql_content = f.read()

    # ── Step 1 : Remove MySQL-specific administrative statements ────────────────
    sql_content = re.sub(r'(?i)DROP\s+DATABASE\s+IF\s+EXISTS[^;]+;', '', sql_content)
    sql_content = re.sub(r'(?i)CREATE\s+DATABASE[^;]+;', '', sql_content)
    sql_content = re.sub(r'(?i)USE\s+\S+\s*;', '', sql_content)

    # ── Step 2 : Convert AUTO_INCREMENT PRIMARY KEY variants ────────────────────
    sql_content = re.sub(
        r'(?i)\bBIGINT\s+AUTO_INCREMENT\s+PRIMARY\s+KEY\b',
        'INTEGER PRIMARY KEY AUTOINCREMENT',
        sql_content
    )
    sql_content = re.sub(
        r'(?i)\b(?:TINY|SMALL|MEDIUM|BIG)?INT(?:\s+UNSIGNED)?\s+AUTO_INCREMENT\s+PRIMARY\s+KEY\b',
        'INTEGER PRIMARY KEY AUTOINCREMENT',
        sql_content
    )

    # ── Step 3 : Replace ENUM(...) with TEXT (SQLite has no ENUM type) ──────────
    sql_content = re.sub(r'(?i)ENUM\s*\([^)]+\)', 'TEXT', sql_content)

    # ── Step 4 : Replace date/time functions ────────────────────────────────────
    sql_content = sql_content.replace('CURDATE()', 'CURRENT_DATE')
    sql_content = sql_content.replace('NOW()', 'CURRENT_TIMESTAMP')

    # ── Step 5 : Strip DECIMAL type precision (keep as REAL) ────────────────────
    # SQLite ignores column types anyway, but this avoids parse warnings
    sql_content = re.sub(r'(?i)\bDECIMAL\s*\(\d+\s*,\s*\d+\)', 'REAL', sql_content)

    # ── Step 6 : Strip BIGINT to INTEGER (SQLite doesn't distinguish) ────────────
    sql_content = re.sub(r'(?i)\bBIGINT\b', 'INTEGER', sql_content)

    # ── Step 7 : Remove trailing comments from lines (-- ...) ───────────────────
    def strip_line_comments(text):
        result = []
        for line in text.split('\n'):
            # Don't strip comment-only lines — they're already excluded below
            result.append(line.split('--')[0] if '--' in line and not line.strip().startswith('--') else line)
        return '\n'.join(result)
    
    sql_content = strip_line_comments(sql_content)

    # ── Step 8 : Split on semicolons and filter ──────────────────────────────────
    raw_statements = sql_content.split(';')
    statements = []
    for raw in raw_statements:
        # Remove comment lines
        lines = [l for l in raw.split('\n') if not l.strip().startswith('--')]
        stmt = '\n'.join(lines).strip()
        if stmt:
            statements.append(stmt)

    # ── Step 9 : Execute against SQLite ─────────────────────────────────────────
    conn = sqlite3.connect(db_path)
    conn.execute("PRAGMA foreign_keys = OFF")   # relax FKs during build
    cursor = conn.cursor()

    success_count = 0
    fail_count = 0

    for stmt in statements:
        stmt_clean = stmt.strip()
        if not stmt_clean:
            continue
        try:
            cursor.execute(stmt_clean)
            success_count += 1
        except Exception as e:
            fail_count += 1
            print(f"  [WARN] Skipping statement (error: {e})\n  → {stmt_clean[:80]}...")

    conn.commit()
    conn.execute("PRAGMA foreign_keys = ON")
    conn.close()

    print(f"Database initialisation complete. ({success_count} OK, {fail_count} skipped)")


if __name__ == '__main__':
    workspace_root = os.path.dirname(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    )
    schema = os.path.join(workspace_root, 'bank_management_system_database.sql')
    db     = os.path.join(workspace_root, 'instance', 'bank.db')
    init_db(schema, db)

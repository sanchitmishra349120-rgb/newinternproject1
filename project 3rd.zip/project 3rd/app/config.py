import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

class Config:
    # Flask configuration
    SECRET_KEY = os.environ.get("SECRET_KEY", "sbi_secret_key_123_change_me")
    FLASK_ENV = os.environ.get("FLASK_ENV", "development")
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = "Lax"
    
    # DB Type: 'mysql' or 'sqlite' (defaults to sqlite if mysql config is incomplete)
    DB_TYPE = os.environ.get("DB_TYPE", "sqlite")
    
    # SQLite configuration
    SQLITE_DB_PATH = os.environ.get("SQLITE_DB_PATH", os.path.join(
        os.path.abspath(os.path.dirname(os.path.dirname(__file__))), 
        "instance", 
        "bank.db"
    ))
    
    # MySQL Database credentials (if DB_TYPE is mysql)
    MYSQL_HOST = os.environ.get("MYSQL_HOST", "localhost")
    MYSQL_PORT = int(os.environ.get("MYSQL_PORT", 3306))
    MYSQL_USER = os.environ.get("MYSQL_USER", "root")
    MYSQL_PASSWORD = os.environ.get("MYSQL_PASSWORD", "")
    MYSQL_DATABASE = os.environ.get("MYSQL_DATABASE", "banking_management_system")

    # ==========================
    # BANK DETAILS
    # ==========================
    BANK_NAME = "Python National Bank"
    BANK_SHORT_NAME = "PNB"
    BANK_IFSC_PREFIX = "PNB000"
    BANK_ADDRESS = "Main Branch, Delhi"

    # ==========================
    # ACCOUNT SETTINGS
    # ==========================
    MINIMUM_SAVINGS_BALANCE = 1000.00
    MINIMUM_CURRENT_BALANCE = 5000.00
    MAX_DAILY_WITHDRAWAL = 50000.00
    MAX_DAILY_TRANSFER = 100000.00
    DEFAULT_ACCOUNT_STATUS = "Active"
    DEFAULT_ACCOUNT_TYPE = "Savings"

    # ==========================
    # ATM SETTINGS
    # ==========================
    ATM_PIN_LENGTH = 4
    MAX_PIN_ATTEMPTS = 3

    # ==========================
    # PASSWORD SETTINGS
    # ==========================
    MIN_PASSWORD_LENGTH = 8
    MAX_LOGIN_ATTEMPTS = 5

    # ==========================
    # LOAN SETTINGS (Interest Rates)
    # ==========================
    HOME_LOAN_INTEREST = 8.50
    VEHICLE_LOAN_INTEREST = 9.25
    EDUCATION_LOAN_INTEREST = 7.80
    PERSONAL_LOAN_INTEREST = 12.50

    LOAN_TYPES = ("Home", "Vehicle", "Education", "Personal")

    # ==========================
    # FD INTEREST RATES
    # ==========================
    FD_INTEREST = {
        12: 6.50,
        24: 6.90,
        36: 7.10,
        60: 7.50
    }

    # ==========================
    # RD INTEREST RATES
    # ==========================
    RD_INTEREST = {
        12: 6.20,
        24: 6.60,
        36: 6.90,
        60: 7.20
    }

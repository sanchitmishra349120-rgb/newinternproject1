import os
from flask import Flask
from app.config import Config
from app.services.db_helper import db

def create_app(config_class=Config):
    app = Flask(__name__)
    app.config.from_object(config_class)

    # Initialize extensions
    db.init_app(app)
    
    # Establish connection
    with app.app_context():
        db.connect()

    # Register blueprints
    from app.routes.auth_routes import auth_bp
    from app.routes.admin_routes import admin_bp
    from app.routes.customer_routes import customer_bp
    from app.routes.banking_routes import banking_bp
    from app.routes.services_routes import services_bp
    from app.routes.beneficiary_routes import beneficiary_bp
    from app.routes.branch_routes import branch_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(admin_bp)
    app.register_blueprint(customer_bp)
    app.register_blueprint(banking_bp)
    app.register_blueprint(services_bp)
    app.register_blueprint(beneficiary_bp)
    app.register_blueprint(branch_bp)

    # Register Jinja template filters
    @app.template_filter("currency")
    def currency_filter(amount):
        from app.services.utils import Utils
        return Utils.format_currency(amount)

    @app.template_filter("mask_account")
    def mask_account_filter(account_number):
        from app.services.utils import Utils
        return Utils.mask_account(account_number)

    @app.template_filter("mask_mobile")
    def mask_mobile_filter(mobile):
        from app.services.utils import Utils
        return Utils.mask_mobile(mobile)

    @app.template_filter("mask_aadhaar")
    def mask_aadhaar_filter(aadhaar):
        from app.services.utils import Utils
        return Utils.mask_aadhaar(aadhaar)

    # Context processors to inject global parameters
    @app.context_processor
    def inject_globals():
        return {
            "bank_name": app.config.get("BANK_NAME", "Python National Bank"),
            "bank_short": app.config.get("BANK_SHORT_NAME", "PNB")
        }

    return app

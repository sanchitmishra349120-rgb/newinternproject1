document.addEventListener("DOMContentLoaded", function () {
    // 1. Auto-hide flash alerts after 5 seconds
    const alerts = document.querySelectorAll(".alert-dismissible");
    alerts.forEach(function (alert) {
        setTimeout(function () {
            // Using bootstrap alert method or styling fade out
            alert.style.transition = "opacity 0.6s ease";
            alert.style.opacity = "0";
            setTimeout(function () {
                alert.remove();
            }, 600);
        }, 5000);
    });

    // 2. Real-time EMI Calculator on Loan Apply Form
    const loanAmountInput = document.getElementById("loan-amount");
    const loanTenureInput = document.getElementById("loan-tenure");
    const loanTypeSelect = document.getElementById("loan-type");
    const emiPreview = document.getElementById("emi-preview");
    const interestPreview = document.getElementById("interest-preview");

    if (loanAmountInput && loanTenureInput && loanTypeSelect && emiPreview) {
        function updateEMI() {
            const principal = parseFloat(loanAmountInput.value) || 0;
            const tenure = parseInt(loanTenureInput.value) || 0;
            const type = loanTypeSelect.value;

            // Interest Rates from rates metadata in page
            let annualRate = 12.0;
            const option = loanTypeSelect.options[loanTypeSelect.selectedIndex];
            if (option && option.dataset.rate) {
                annualRate = parseFloat(option.dataset.rate);
            }

            if (interestPreview) {
                interestPreview.textContent = annualRate.toFixed(2) + "%";
            }

            if (principal > 0 && tenure > 0) {
                const monthlyRate = annualRate / (12 * 100);
                let emi = 0;
                if (monthlyRate === 0) {
                    emi = principal / tenure;
                } else {
                    emi = (principal * monthlyRate * Math.pow(1 + monthlyRate, tenure)) / (Math.pow(1 + monthlyRate, tenure) - 1);
                }
                
                emiPreview.textContent = "₹" + emi.toLocaleString('en-IN', {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                });
            } else {
                emiPreview.textContent = "₹0.00";
            }
        }

        loanAmountInput.addEventListener("input", updateEMI);
        loanTenureInput.addEventListener("input", updateEMI);
        loanTypeSelect.addEventListener("change", updateEMI);
        
        // Run initial calculation
        updateEMI();
    }
});

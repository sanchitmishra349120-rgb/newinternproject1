from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from werkzeug.security import generate_password_hash, check_password_hash
from app.models.customer import CustomerModel
from app.models.account import AccountModel
from app.models.admin import AdminModel
from app.models.branch import BranchModel
from app.services.validations import Validator
from app.services.utils import Utils
from app.services.db_helper import db

auth_bp = Blueprint("auth", __name__)


def check_password(stored_password, input_password):
    """Support both legacy plain-text passwords and Werkzeug PBKDF2 hashes."""
    if stored_password and stored_password.startswith(("pbkdf2:", "scrypt:")):
        return check_password_hash(stored_password, input_password)
    return stored_password == input_password


# ──────────────────────────────────────────────────────────────────────────────
# Home / Landing page
# ──────────────────────────────────────────────────────────────────────────────
@auth_bp.route("/")
def index():
    if session.get("admin_logged_in"):
        return redirect(url_for("admin.dashboard"))
    if session.get("customer_logged_in"):
        return redirect(url_for("customer.dashboard"))
    return render_template("index.html")


# ──────────────────────────────────────────────────────────────────────────────
# Admin Login
# ──────────────────────────────────────────────────────────────────────────────
@auth_bp.route("/admin/login", methods=["GET", "POST"])
def admin_login():
    if session.get("admin_logged_in"):
        return redirect(url_for("admin.dashboard"))

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "").strip()

        admin = AdminModel.get_by_username(username)
        if admin and check_password(admin["password"], password):
            session.clear()
            session["admin_logged_in"]  = True
            session["admin_id"]         = admin["admin_id"]
            session["admin_username"]   = admin["username"]
            session["admin_name"]       = admin.get("full_name", admin["username"])

            db.execute(
                "INSERT INTO audit_log (admin_id, action) VALUES (%s, %s)",
                (admin["admin_id"], f"Admin login from {request.remote_addr}")
            )
            flash("Admin login successful!", "success")
            return redirect(url_for("admin.dashboard"))

        flash("Invalid admin username or password.", "danger")

    return render_template("auth/admin_login.html")


# ──────────────────────────────────────────────────────────────────────────────
# Customer Login
# ──────────────────────────────────────────────────────────────────────────────
@auth_bp.route("/customer/login", methods=["GET", "POST"])
def customer_login():
    if session.get("customer_logged_in"):
        return redirect(url_for("customer.dashboard"))

    if request.method == "POST":
        account_number_str = request.form.get("account_number", "").strip()
        password           = request.form.get("password", "").strip()

        if not account_number_str.isdigit():
            flash("Account number must be numeric.", "danger")
            return render_template("auth/customer_login.html")

        account_number = int(account_number_str)
        account = AccountModel.get_details(account_number)

        if account:
            if account["status"] != "Active":
                flash(f"Account is {account['status']}. Please contact your branch.", "warning")
                return render_template("auth/customer_login.html")

            if check_password(account["login_password"], password):
                session.clear()
                session["customer_logged_in"] = True
                session["customer_id"]        = account["customer_id"]
                session["account_number"]     = account["account_number"]
                session["customer_name"]      = f"{account['first_name']} {account['last_name']}"

                db.execute(
                    "INSERT INTO login_history (account_number, ip_address) VALUES (%s, %s)",
                    (account["account_number"], request.remote_addr or "127.0.0.1")
                )
                flash("Login successful!", "success")
                return redirect(url_for("customer.dashboard"))

        flash("Invalid account number or password.", "danger")

    return render_template("auth/customer_login.html")


# ──────────────────────────────────────────────────────────────────────────────
# Customer Registration
# ──────────────────────────────────────────────────────────────────────────────
@auth_bp.route("/customer/register", methods=["GET", "POST"])
def register():
    if session.get("customer_logged_in"):
        return redirect(url_for("customer.dashboard"))

    branches = BranchModel.get_all()

    if request.method == "POST":
        f = request.form          # shorthand

        first_name       = f.get("first_name",       "").strip().title()
        last_name        = f.get("last_name",        "").strip().title()
        gender           = f.get("gender",           "")
        dob              = f.get("dob",              "")
        mobile           = f.get("mobile",           "").strip()
        email            = f.get("email",            "").strip()
        aadhaar          = f.get("aadhaar",          "").strip()
        pan              = f.get("pan",              "").strip().upper()
        address          = f.get("address",          "").strip()
        city             = f.get("city",             "").strip().title()
        state            = f.get("state",            "").strip().title()
        pincode          = f.get("pincode",          "").strip()
        branch_id_str    = f.get("branch_id",        "")
        account_type     = f.get("account_type",     "Savings")
        initial_dep_str  = f.get("initial_deposit",  "0")
        password         = f.get("password",         "").strip()
        atm_pin          = f.get("atm_pin",          "").strip()

        # ── Validations ──────────────────────────────────────────────────────
        errors = []
        if not Validator.validate_name(first_name):
            errors.append("Invalid first name (alphabets & spaces only, 2–50 chars).")
        if last_name and not Validator.validate_name(last_name):
            errors.append("Invalid last name (alphabets & spaces only, 2–50 chars).")
        if not Validator.validate_gender(gender):
            errors.append("Please select a valid gender.")
        if not Validator.validate_dob(dob):
            errors.append("Customer must be at least 18 years old.")
        if not Validator.validate_mobile(mobile):
            errors.append("Invalid mobile number (10 digits starting with 6–9).")
        if not Validator.validate_email(email):
            errors.append("Invalid email address.")
        if not Validator.validate_aadhaar(aadhaar):
            errors.append("Invalid Aadhaar number (exactly 12 digits).")
        if not Validator.validate_pan(pan):
            errors.append("Invalid PAN number (format: ABCDE1234F).")
        if not Validator.validate_pincode(pincode):
            errors.append("Invalid pincode (6 digits).")
        if not Validator.validate_password(password):
            errors.append("Password must be 8+ characters with uppercase, lowercase, digit & special character (@$!%*?&).")
        if atm_pin and not Validator.validate_atm_pin(atm_pin):
            errors.append("ATM PIN must be exactly 4 digits.")

        # Uniqueness checks
        if CustomerModel.get_by_mobile(mobile):
            errors.append("Mobile number is already registered.")
        if CustomerModel.get_by_email(email):
            errors.append("Email address is already registered.")
        if CustomerModel.get_by_aadhaar(aadhaar):
            errors.append("Aadhaar number is already registered.")
        if CustomerModel.get_by_pan(pan):
            errors.append("PAN number is already registered.")

        try:
            initial_deposit = float(initial_dep_str)
            min_bal = 1000.0 if account_type == "Savings" else 5000.0
            if initial_deposit < min_bal:
                errors.append(
                    f"Initial deposit must be at least ₹{min_bal:,.2f} for a {account_type} account."
                )
        except ValueError:
            errors.append("Initial deposit must be a valid number.")

        if errors:
            for err in errors:
                flash(err, "danger")
            return render_template("auth/register.html", branches=branches, form=f)

        # ── All valid → persist within a transaction ─────────────────────────
        try:
            db.begin()

            customer_id = CustomerModel.create(
                first_name, last_name, gender, dob, mobile, email,
                aadhaar, pan, address, city, state, pincode
            )
            if not customer_id:
                raise Exception("Failed to insert customer record.")

            # Generate unique 12-digit account number
            while True:
                account_num = Utils.generate_account_number()
                if not AccountModel.get_by_number(account_num):
                    break

            hashed_pwd = generate_password_hash(password)
            branch_id  = int(branch_id_str)

            ok = AccountModel.create(
                account_num, customer_id, branch_id,
                account_type, initial_deposit,
                hashed_pwd, atm_pin or None
            )
            if not ok:
                raise Exception("Failed to insert account record.")

            from app.models.transaction import TransactionModel
            TransactionModel.record(
                account_num, "Deposit", initial_deposit,
                initial_deposit, "Account Opening Balance"
            )

            db.commit()
            flash(
                f"Registration successful! Your Account Number is "
                f"<strong>{account_num}</strong>. Please login.",
                "success"
            )
            return redirect(url_for("auth.customer_login"))

        except Exception as e:
            db.rollback()
            flash(f"Registration error: {e}", "danger")

    return render_template("auth/register.html", branches=branches)


# ──────────────────────────────────────────────────────────────────────────────
# Change Password
# ──────────────────────────────────────────────────────────────────────────────
@auth_bp.route("/change-password", methods=["POST"])
def change_password():
    if not session.get("customer_logged_in"):
        flash("Please login to change your password.", "danger")
        return redirect(url_for("auth.customer_login"))

    old_password     = request.form.get("old_password",     "")
    new_password     = request.form.get("new_password",     "")
    confirm_password = request.form.get("confirm_password", "")

    account_number = session["account_number"]
    account        = AccountModel.get_by_number(account_number)

    if not account or not check_password(account["login_password"], old_password):
        flash("Current password is incorrect.", "danger")
        return redirect(url_for("customer.profile"))

    if new_password != confirm_password:
        flash("New passwords do not match.", "danger")
        return redirect(url_for("customer.profile"))

    if not Validator.validate_password(new_password):
        flash("New password does not meet complexity requirements.", "danger")
        return redirect(url_for("customer.profile"))

    hashed = generate_password_hash(new_password)
    if db.execute(
        "UPDATE account SET login_password = %s WHERE account_number = %s",
        (hashed, account_number)
    ):
        flash("Password updated successfully!", "success")
    else:
        flash("Failed to update password.", "danger")

    return redirect(url_for("customer.profile"))


# ──────────────────────────────────────────────────────────────────────────────
# Logout
# ──────────────────────────────────────────────────────────────────────────────
@auth_bp.route("/logout")
def logout():
    account_number = session.get("account_number")
    admin_id       = session.get("admin_id")

    if account_number:
        db.execute(
            "UPDATE login_history SET logout_time = CURRENT_TIMESTAMP "
            "WHERE account_number = %s AND logout_time IS NULL",
            (account_number,)
        )

    if admin_id:
        db.execute(
            "INSERT INTO audit_log (admin_id, action) VALUES (%s, %s)",
            (admin_id, "Admin logout")
        )

    session.clear()
    flash("You have been logged out.", "info")
    return redirect(url_for("auth.index"))

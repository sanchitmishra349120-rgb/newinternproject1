from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from app.routes.customer_routes import customer_required
from app.models import AccountModel, TransactionModel, BeneficiaryModel
from app.services.validations import Validator
from app.services.utils import Utils
from app.services.db_helper import db
from app.config import Config

banking_bp = Blueprint("banking", __name__)

@banking_bp.route("/customer/deposit-withdraw", methods=["GET", "POST"])
@customer_required
def deposit_withdraw():
    account_number = session["account_number"]
    account = AccountModel.get_by_number(account_number)
    
    if not account:
        flash("Account not found.", "danger")
        return redirect(url_for("customer.dashboard"))
        
    if request.method == "POST":
        action = request.form.get("action")  # "deposit" or "withdraw"
        amount_str = request.form.get("amount", "").strip()
        description = request.form.get("description", "").strip()
        
        if not Validator.validate_amount(amount_str):
            flash("Please enter a valid amount greater than zero.", "danger")
            return redirect(url_for("banking.deposit_withdraw"))
            
        amount = float(amount_str)
        current_balance = float(account["balance"])
        
        if action == "deposit":
            new_balance = current_balance + amount
            desc = description or "Self Deposit"
            
            if AccountModel.update_balance(account_number, new_balance):
                TransactionModel.record(account_number, "Deposit", amount, new_balance, desc)
                flash(f"Successfully deposited ₹{amount:,.2f}. New balance is {Utils.format_currency(new_balance)}.", "success")
            else:
                flash("Failed to process deposit.", "danger")
                
        elif action == "withdraw":
            min_bal = Config.MINIMUM_SAVINGS_BALANCE if account["account_type"] == "Savings" else Config.MINIMUM_CURRENT_BALANCE
            
            if current_balance - amount < min_bal:
                flash(f"Insufficient funds! You must maintain a minimum balance of ₹{min_bal:,.2f} for {account['account_type']} account.", "danger")
                return redirect(url_for("banking.deposit_withdraw"))
                
            new_balance = current_balance - amount
            desc = description or "Self Withdrawal"
            
            if AccountModel.update_balance(account_number, new_balance):
                TransactionModel.record(account_number, "Withdraw", amount, new_balance, desc)
                flash(f"Successfully withdrew ₹{amount:,.2f}. New balance is {Utils.format_currency(new_balance)}.", "success")
            else:
                flash("Failed to process withdrawal.", "danger")
                
        return redirect(url_for("customer.dashboard"))
        
    return render_template("customer/deposit_withdraw.html", account=account)

@banking_bp.route("/customer/transfer", methods=["GET", "POST"])
@customer_required
def transfer():
    account_number = session["account_number"]
    account = AccountModel.get_by_number(account_number)
    
    if not account:
        flash("Account not found.", "danger")
        return redirect(url_for("customer.dashboard"))
        
    beneficiaries = BeneficiaryModel.get_by_account(account_number)
    
    if request.method == "POST":
        receiver_account_str = request.form.get("receiver_account", "").strip()
        amount_str = request.form.get("amount", "").strip()
        description = request.form.get("description", "").strip()
        
        if not receiver_account_str.isdigit():
            flash("Beneficiary Account Number must be numeric.", "danger")
            return redirect(url_for("banking.transfer"))
            
        receiver_account_number = int(receiver_account_str)
        
        if receiver_account_number == account_number:
            flash("You cannot transfer money to your own account.", "danger")
            return redirect(url_for("banking.transfer"))
            
        if not Validator.validate_amount(amount_str):
            flash("Please enter a valid amount greater than zero.", "danger")
            return redirect(url_for("banking.transfer"))
            
        amount = float(amount_str)
        
        # Verify sender balance
        current_balance = float(account["balance"])
        min_bal = Config.MINIMUM_SAVINGS_BALANCE if account["account_type"] == "Savings" else Config.MINIMUM_CURRENT_BALANCE
        
        if current_balance - amount < min_bal:
            flash(f"Insufficient funds! You must maintain a minimum balance of ₹{min_bal:,.2f}.", "danger")
            return redirect(url_for("banking.transfer"))
            
        # Verify receiver exists and is active
        receiver_account = AccountModel.get_by_number(receiver_account_number)
        if not receiver_account:
            flash("Recipient account not found.", "danger")
            return redirect(url_for("banking.transfer"))
            
        if receiver_account["status"] != "Active":
            flash("Recipient account is not active.", "danger")
            return redirect(url_for("banking.transfer"))
            
        # Process within database transaction
        try:
            db.begin()
            
            # 1. Debit sender
            sender_new_balance = current_balance - amount
            AccountModel.update_balance(account_number, sender_new_balance)
            
            # 2. Credit receiver
            receiver_new_balance = float(receiver_account["balance"]) + amount
            AccountModel.update_balance(receiver_account_number, receiver_new_balance)
            
            # 3. Record transactions
            desc_sender = description or f"Transfer to A/C: {receiver_account_number}"
            TransactionModel.record(account_number, "Transfer", amount, sender_new_balance, f"Debit: {desc_sender}")
            
            desc_receiver = f"Transfer from A/C: {account_number}"
            TransactionModel.record(receiver_account_number, "Transfer", amount, receiver_new_balance, f"Credit: {desc_receiver}")
            
            db.commit()
            flash(f"Successfully transferred ₹{amount:,.2f} to Account: {receiver_account_number}.", "success")
            return redirect(url_for("customer.dashboard"))
            
        except Exception as e:
            db.rollback()
            flash(f"Transfer failed. Error: {str(e)}", "danger")
            return redirect(url_for("banking.transfer"))
            
    return render_template("customer/transfer.html", account=account, beneficiaries=beneficiaries)

@banking_bp.route("/customer/transactions")
@customer_required
def transactions():
    account_number = session["account_number"]
    txn_list = TransactionModel.get_by_account(account_number)
    return render_template("customer/transactions.html", transactions=txn_list)

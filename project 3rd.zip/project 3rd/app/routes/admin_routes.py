from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from functools import wraps
from app.models import CustomerModel, AccountModel, TransactionModel, LoanModel, BranchModel, AdminModel
from app.services.db_helper import db

admin_bp = Blueprint("admin", __name__)

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not session.get("admin_logged_in"):
            flash("Administrator login required.", "danger")
            return redirect(url_for("auth.admin_login"))
        return f(*args, **kwargs)
    return decorated_function

@admin_bp.route("/admin/dashboard")
@admin_required
def dashboard():
    # Statistics
    total_customers = db.fetch_one("SELECT COUNT(*) as count FROM customer")["count"]
    total_accounts_data = db.fetch_one("SELECT COUNT(*) as count, SUM(balance) as total_bal FROM account")
    total_accounts = total_accounts_data["count"]
    total_deposits = float(total_accounts_data["total_bal"]) if total_accounts_data["total_bal"] else 0.0
    
    total_loans_data = db.fetch_one("SELECT COUNT(*) as count, SUM(amount) as total_amt FROM loan WHERE status='Approved'")
    total_loans = total_loans_data["count"]
    total_loan_amount = float(total_loans_data["total_amt"]) if total_loans_data["total_amt"] else 0.0
    
    total_branches = db.fetch_one("SELECT COUNT(*) as count FROM branch")["count"]
    
    # Recent Loans
    recent_loans = db.fetch_all("""
        SELECT l.*, c.first_name, c.last_name 
        FROM loan l 
        JOIN account a ON l.account_number = a.account_number
        JOIN customer c ON a.customer_id = c.customer_id
        ORDER BY l.applied_date DESC LIMIT 5
    """)
    
    # Recent Transactions
    recent_txns = TransactionModel.get_recent(5)
    
    return render_template("admin/dashboard.html",
                           total_customers=total_customers,
                           total_accounts=total_accounts,
                           total_deposits=total_deposits,
                           total_loans=total_loans,
                           total_loan_amount=total_loan_amount,
                           total_branches=total_branches,
                           recent_loans=recent_loans,
                           recent_txns=recent_txns)

@admin_bp.route("/admin/customers")
@admin_required
def customers():
    search_query = request.args.get("search", "").strip()
    if search_query:
        customer_list = CustomerModel.search(search_query)
    else:
        customer_list = CustomerModel.get_all()
    return render_template("admin/customers.html", customers=customer_list, search=search_query)

@admin_bp.route("/admin/accounts")
@admin_required
def accounts():
    search_query = request.args.get("search", "").strip()
    if search_query:
        account_list = AccountModel.search(search_query)
    else:
        account_list = AccountModel.get_all()
    return render_template("admin/accounts.html", accounts=account_list, search=search_query)

@admin_bp.route("/admin/transactions")
@admin_required
def transactions():
    txn_list = TransactionModel.get_all()
    return render_template("admin/transactions.html", transactions=txn_list)

@admin_bp.route("/admin/loans", methods=["GET", "POST"])
@admin_required
def loans():
    loan_list = LoanModel.get_all()
    return render_template("admin/loans.html", loans=loan_list)

@admin_bp.route("/admin/loans/approve/<int:loan_id>", methods=["POST"])
@admin_required
def approve_loan(loan_id):
    loan = LoanModel.get_by_id(loan_id)
    if not loan:
        flash("Loan application not found.", "danger")
        return redirect(url_for("admin.loans"))
        
    if loan["status"] != "Pending":
        flash(f"This loan application has already been {loan['status']}.", "warning")
        return redirect(url_for("admin.loans"))
        
    # Get associated customer account
    account_number = loan["account_number"]
    account = AccountModel.get_by_number(account_number)
    
    if not account:
        flash("Associated account not found.", "danger")
        return redirect(url_for("admin.loans"))
        
    loan_amount = float(loan["amount"])
    new_balance = float(account["balance"]) + loan_amount
    
    try:
        db.begin()
        
        # 1. Update loan status
        LoanModel.update_status(loan_id, "Approved")
        
        # 2. Credit the customer account balance
        AccountModel.update_balance(account_number, new_balance)
        
        # 3. Log transactional debit/credit (Disbursed Loan is a credit)
        TransactionModel.record(
            account_number,
            "Loan",
            loan_amount,
            new_balance,
            f"Loan Disbursal - ID: {loan_id} ({loan['loan_type']} Loan)"
        )
        
        # 4. Log in admin audit log
        db.execute("INSERT INTO audit_log (admin_id, action) VALUES (%s, %s)",
                   (session["admin_id"], f"Approved loan ID: {loan_id} for account: {account_number}"))
                   
        db.commit()
        flash(f"Loan ID: {loan_id} has been Approved and credited to Account: {account_number}.", "success")
        
    except Exception as e:
        db.rollback()
        flash(f"Failed to approve loan. Error: {str(e)}", "danger")
        
    return redirect(url_for("admin.loans"))

@admin_bp.route("/admin/loans/reject/<int:loan_id>", methods=["POST"])
@admin_required
def reject_loan(loan_id):
    loan = LoanModel.get_by_id(loan_id)
    if not loan:
        flash("Loan application not found.", "danger")
        return redirect(url_for("admin.loans"))
        
    if loan["status"] != "Pending":
        flash(f"This loan application has already been {loan['status']}.", "warning")
        return redirect(url_for("admin.loans"))
        
    if LoanModel.update_status(loan_id, "Rejected"):
        db.execute("INSERT INTO audit_log (admin_id, action) VALUES (%s, %s)",
                   (session["admin_id"], f"Rejected loan ID: {loan_id}"))
        flash(f"Loan ID: {loan_id} has been Rejected.", "info")
    else:
        flash("Failed to reject loan.", "danger")
        
    return redirect(url_for("admin.loans"))

@admin_bp.route("/admin/deposits")
@admin_required
def deposits():
    # Fixed deposits list
    fd_list = db.fetch_all("""
        SELECT fd.*, c.first_name, c.last_name 
        FROM fixed_deposit fd 
        JOIN account a ON fd.account_number = a.account_number 
        JOIN customer c ON a.customer_id = c.customer_id
        ORDER BY fd.start_date DESC
    """)
    # Recurring deposits list
    rd_list = db.fetch_all("""
        SELECT rd.*, c.first_name, c.last_name 
        FROM recurring_deposit rd 
        JOIN account a ON rd.account_number = a.account_number 
        JOIN customer c ON a.customer_id = c.customer_id
        ORDER BY rd.start_date DESC
    """)
    return render_template("admin/deposits.html", fds=fd_list, rds=rd_list)

@admin_bp.route("/admin/branches", methods=["GET", "POST"])
@admin_required
def branches():
    if request.method == "POST":
        branch_name = request.form.get("branch_name", "").strip()
        branch_code = request.form.get("branch_code", "").strip().upper()
        ifsc_code = request.form.get("ifsc_code", "").strip().upper()
        address = request.form.get("address", "").strip()
        city = request.form.get("city", "").strip()
        state = request.form.get("state", "").strip()
        pincode = request.form.get("pincode", "").strip()
        
        # Simple validations
        if not branch_name or not branch_code or not ifsc_code:
            flash("Branch name, code, and IFSC code are required.", "danger")
        elif BranchModel.get_by_code(branch_code):
            flash("Branch code already exists.", "danger")
        elif db.fetch_one("SELECT branch_id FROM branch WHERE ifsc_code=%s", (ifsc_code,)):
            flash("IFSC code already exists.", "danger")
        else:
            success = BranchModel.create(branch_name, branch_code, ifsc_code, address, city, state, pincode)
            if success:
                db.execute("INSERT INTO audit_log (admin_id, action) VALUES (%s, %s)",
                           (session["admin_id"], f"Added new branch: {branch_name} ({branch_code})"))
                flash("Branch added successfully!", "success")
                return redirect(url_for("admin.branches"))
            else:
                flash("Database error adding branch.", "danger")
                
    branch_list = BranchModel.get_all()
    return render_template("admin/branches.html", branches=branch_list)

from flask import Blueprint, render_template, redirect, url_for, flash, session
from functools import wraps
from app.models import CustomerModel, AccountModel, TransactionModel, BranchModel
from app.services.db_helper import db

customer_bp = Blueprint("customer", __name__)

def customer_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not session.get("customer_logged_in"):
            flash("Please login to access your customer dashboard.", "danger")
            return redirect(url_for("auth.customer_login"))
        return f(*args, **kwargs)
    return decorated_function

@customer_bp.route("/customer/dashboard")
@customer_required
def dashboard():
    account_number = session["account_number"]
    account = AccountModel.get_details(account_number)
    
    if not account:
        flash("Unable to fetch account details.", "danger")
        return redirect(url_for("auth.logout"))
        
    # Get all other accounts linked to this customer
    all_accounts = AccountModel.get_by_customer_id(session["customer_id"])
    
    # Recent Transactions for this specific account
    recent_transactions = TransactionModel.get_recent_by_account(account_number, 5)
    
    # Fetch user summary details (e.g. loan totals, fd/rd counts)
    loan_summary = db.fetch_one("""
        SELECT COUNT(*) as count, SUM(amount) as total 
        FROM loan 
        WHERE account_number = %s AND status = 'Approved'
    """, (account_number,))
    
    fd_summary = db.fetch_one("""
        SELECT COUNT(*) as count, SUM(amount) as total 
        FROM fixed_deposit 
        WHERE account_number = %s
    """, (account_number,))
    
    rd_summary = db.fetch_one("""
        SELECT COUNT(*) as count, SUM(monthly_amount) as total 
        FROM recurring_deposit 
        WHERE account_number = %s
    """, (account_number,))
    
    return render_template("customer/dashboard.html",
                           account=account,
                           all_accounts=all_accounts,
                           recent_txns=recent_transactions,
                           loan_count=loan_summary["count"] if loan_summary else 0,
                           loan_total=float(loan_summary["total"]) if loan_summary and loan_summary["total"] else 0.0,
                           fd_count=fd_summary["count"] if fd_summary else 0,
                           fd_total=float(fd_summary["total"]) if fd_summary and fd_summary["total"] else 0.0,
                           rd_count=rd_summary["count"] if rd_summary else 0,
                           rd_total=float(rd_summary["total"]) if rd_summary and rd_summary["total"] else 0.0)

@customer_bp.route("/customer/profile")
@customer_required
def profile():
    customer_id = session["customer_id"]
    customer = CustomerModel.get_by_id(customer_id)
    account_number = session["account_number"]
    account = AccountModel.get_details(account_number)
    
    from app.services.utils import Utils
    masked_aadhaar = Utils.mask_aadhaar(customer["aadhaar"]) if customer.get("aadhaar") else ""
    masked_mobile = Utils.mask_mobile(customer["mobile"]) if customer.get("mobile") else ""
    
    return render_template("customer/profile.html", 
                           customer=customer, 
                           account=account, 
                           masked_aadhaar=masked_aadhaar, 
                           masked_mobile=masked_mobile)

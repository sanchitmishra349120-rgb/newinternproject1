from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from app.routes.customer_routes import customer_required
from app.models import BeneficiaryModel, AccountModel
from app.services.validations import Validator

beneficiary_bp = Blueprint("beneficiary", __name__)

@beneficiary_bp.route("/customer/beneficiaries")
@customer_required
def list_beneficiaries():
    account_number = session["account_number"]
    beneficiary_list = BeneficiaryModel.get_by_account(account_number)
    return render_template("customer/beneficiaries.html", beneficiaries=beneficiary_list)

@beneficiary_bp.route("/customer/beneficiaries/add", methods=["POST"])
@customer_required
def add_beneficiary():
    account_number = session["account_number"]
    beneficiary_acc_str = request.form.get("beneficiary_account", "").strip()
    beneficiary_name = request.form.get("beneficiary_name", "").strip()
    
    if not beneficiary_acc_str.isdigit():
        flash("Beneficiary Account Number must be numeric.", "danger")
        return redirect(url_for("beneficiary.list_beneficiaries"))
        
    beneficiary_account = int(beneficiary_acc_str)
    
    if beneficiary_account == account_number:
        flash("You cannot add yourself as a beneficiary.", "danger")
        return redirect(url_for("beneficiary.list_beneficiaries"))
        
    # Check if recipient account exists
    rec_account = AccountModel.get_details(beneficiary_account)
    if not rec_account:
        flash("Beneficiary account number does not exist.", "danger")
        return redirect(url_for("beneficiary.list_beneficiaries"))
        
    # Check if already added
    if BeneficiaryModel.exists(account_number, beneficiary_account):
        flash("This account is already in your beneficiary list.", "warning")
        return redirect(url_for("beneficiary.list_beneficiaries"))
        
    # Default name if empty
    name = beneficiary_name or f"{rec_account['first_name']} {rec_account['last_name']}"
    
    success = BeneficiaryModel.add(account_number, beneficiary_account, name)
    if success:
        flash(f"Successfully added {name} (A/C: {beneficiary_account}) to beneficiaries.", "success")
    else:
        flash("Failed to add beneficiary.", "danger")
        
    return redirect(url_for("beneficiary.list_beneficiaries"))

@beneficiary_bp.route("/customer/beneficiaries/delete/<int:beneficiary_id>", methods=["POST"])
@customer_required
def delete_beneficiary(beneficiary_id):
    if BeneficiaryModel.delete(beneficiary_id):
        flash("Beneficiary removed successfully.", "info")
    else:
        flash("Failed to remove beneficiary.", "danger")
    return redirect(url_for("beneficiary.list_beneficiaries"))

from flask import Blueprint, render_template
from app.routes.customer_routes import customer_required
from app.models import BranchModel

branch_bp = Blueprint("branch", __name__)

@branch_bp.route("/customer/branches")
@customer_required
def list_branches():
    branch_list = BranchModel.get_all()
    return render_template("customer/branches.html", branches=branch_list)

from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from datetime import datetime, timedelta
from app.routes.customer_routes import customer_required
from app.models import AccountModel, LoanModel, FixedDepositModel, RecurringDepositModel, TransactionModel
from app.services.validations import Validator
from app.services.utils import Utils
from app.services.db_helper import db
from app.config import Config

services_bp = Blueprint("services", __name__)

@services_bp.route("/customer/loans", methods=["GET", "POST"])
@customer_required
def loans():
    account_number = session["account_number"]
    account = AccountModel.get_by_number(account_number)
    
    if request.method == "POST":
        loan_type = request.form.get("loan_type", "")
        amount_str = request.form.get("amount", "").strip()
        tenure_str = request.form.get("tenure", "").strip()
        
        errors = []
        if loan_type not in Config.LOAN_TYPES:
            errors.append("Invalid loan type selected.")
        if not Validator.validate_amount(amount_str):
            errors.append("Please enter a valid loan amount.")
        if not Validator.validate_tenure(tenure_str):
            errors.append("Please enter a valid tenure in months.")
            
        if errors:
            for err in errors:
                flash(err, "danger")
            return redirect(url_for("services.loans"))
            
        amount = float(amount_str)
        tenure = int(tenure_str)
        
        # Determine interest rate
        rate = 12.0
        if loan_type == "Home":
            rate = Config.HOME_LOAN_INTEREST
        elif loan_type == "Vehicle":
            rate = Config.VEHICLE_LOAN_INTEREST
        elif loan_type == "Education":
            rate = Config.EDUCATION_LOAN_INTEREST
        elif loan_type == "Personal":
            rate = Config.PERSONAL_LOAN_INTEREST
            
        success = LoanModel.apply(account_number, loan_type, amount, rate, tenure)
        if success:
            flash(f"Loan Application for ₹{amount:,.2f} ({loan_type}) submitted successfully! Estimated Monthly EMI: {Utils.format_currency(Utils.calculate_emi(amount, rate, tenure))}.", "success")
        else:
            flash("Failed to submit loan application.", "danger")
            
        return redirect(url_for("services.loans"))
        
    my_loans = LoanModel.get_by_account(account_number)
    
    # Pre-calculate interest rates for preview in forms
    rates = {
        "Home": Config.HOME_LOAN_INTEREST,
        "Vehicle": Config.VEHICLE_LOAN_INTEREST,
        "Education": Config.EDUCATION_LOAN_INTEREST,
        "Personal": Config.PERSONAL_LOAN_INTEREST
    }
    
    return render_template("customer/loans.html", loans=my_loans, rates=rates, account=account)

@services_bp.route("/customer/fd", methods=["GET", "POST"])
@customer_required
def fd():
    account_number = session["account_number"]
    account = AccountModel.get_by_number(account_number)
    
    if request.method == "POST":
        amount_str = request.form.get("amount", "").strip()
        tenure_str = request.form.get("tenure", "").strip()
        
        if not Validator.validate_amount(amount_str):
            flash("Please enter a valid deposit amount.", "danger")
            return redirect(url_for("services.fd"))
        if not Validator.validate_tenure(tenure_str):
            flash("Please enter a valid tenure in months.", "danger")
            return redirect(url_for("services.fd"))
            
        amount = float(amount_str)
        tenure = int(tenure_str)
        
        # Check minimum balance
        current_balance = float(account["balance"])
        min_bal = Config.MINIMUM_SAVINGS_BALANCE if account["account_type"] == "Savings" else Config.MINIMUM_CURRENT_BALANCE
        
        if current_balance - amount < min_bal:
            flash(f"Insufficient funds! You must maintain a minimum balance of ₹{min_bal:,.2f} in your primary account.", "danger")
            return redirect(url_for("services.fd"))
            
        # Determine interest rate (fallback to 6.5% if not matched exactly in Config dictionary)
        rate = Config.FD_INTEREST.get(tenure, 6.50)
        
        # Calculations
        maturity_amount = Utils.calculate_fd_maturity(amount, rate, tenure)
        maturity_date = (datetime.now() + timedelta(days=tenure * 30)).strftime("%Y-%m-%d")
        
        try:
            db.begin()
            
            # 1. Debit account balance
            new_balance = current_balance - amount
            AccountModel.update_balance(account_number, new_balance)
            
            # 2. Record transaction log
            TransactionModel.record(account_number, "FD", amount, new_balance, f"Fixed Deposit Booked (ID: {tenure} Months)")
            
            # 3. Create FD record
            FixedDepositModel.create(account_number, amount, rate, tenure, maturity_date, maturity_amount)
            
            db.commit()
            flash(f"Fixed Deposit of ₹{amount:,.2f} opened successfully! Maturity value: {Utils.format_currency(maturity_amount)} on {maturity_date}.", "success")
            
        except Exception as e:
            db.rollback()
            flash(f"Failed to open Fixed Deposit. Error: {str(e)}", "danger")
            
        return redirect(url_for("services.fd"))
        
    my_fds = FixedDepositModel.get_by_account(account_number)
    return render_template("customer/fd.html", fds=my_fds, rates=Config.FD_INTEREST, account=account)

@services_bp.route("/customer/rd", methods=["GET", "POST"])
@customer_required
def rd():
    account_number = session["account_number"]
    account = AccountModel.get_by_number(account_number)
    
    if request.method == "POST":
        monthly_amount_str = request.form.get("monthly_amount", "").strip()
        tenure_str = request.form.get("tenure", "").strip()
        
        if not Validator.validate_amount(monthly_amount_str):
            flash("Please enter a valid monthly contribution amount.", "danger")
            return redirect(url_for("services.rd"))
        if not Validator.validate_tenure(tenure_str):
            flash("Please enter a valid tenure in months.", "danger")
            return redirect(url_for("services.rd"))
            
        monthly_amount = float(monthly_amount_str)
        tenure = int(tenure_str)
        
        # Enforce minimum balance check for first month contribution
        current_balance = float(account["balance"])
        min_bal = Config.MINIMUM_SAVINGS_BALANCE if account["account_type"] == "Savings" else Config.MINIMUM_CURRENT_BALANCE
        
        if current_balance - monthly_amount < min_bal:
            flash(f"Insufficient funds! You need at least ₹{monthly_amount:,.2f} available without breaching your minimum balance to open this RD.", "danger")
            return redirect(url_for("services.rd"))
            
        # Determine interest rate (fallback to 6.2% if not matched exactly in Config dictionary)
        rate = Config.RD_INTEREST.get(tenure, 6.20)
        
        # Calculations
        maturity_amount = Utils.calculate_rd_maturity(monthly_amount, rate, tenure)
        maturity_date = (datetime.now() + timedelta(days=tenure * 30)).strftime("%Y-%m-%d")
        
        try:
            db.begin()
            
            # 1. Debit first month contribution
            new_balance = current_balance - monthly_amount
            AccountModel.update_balance(account_number, new_balance)
            
            # 2. Record transaction log
            TransactionModel.record(account_number, "RD", monthly_amount, new_balance, f"RD Initial Contribution (ID: {tenure} Months)")
            
            # 3. Create RD record
            RecurringDepositModel.create(account_number, monthly_amount, rate, tenure, maturity_date, maturity_amount)
            
            db.commit()
            flash(f"Recurring Deposit opened successfully! Monthly amount: ₹{monthly_amount:,.2f}. Maturity value: {Utils.format_currency(maturity_amount)} on {maturity_date}.", "success")
            
        except Exception as e:
            db.rollback()
            flash(f"Failed to open Recurring Deposit. Error: {str(e)}", "danger")
            
        return redirect(url_for("services.rd"))
        
    my_rds = RecurringDepositModel.get_by_account(account_number)
    return render_template("customer/rd.html", rds=my_rds, rates=Config.RD_INTEREST, account=account)

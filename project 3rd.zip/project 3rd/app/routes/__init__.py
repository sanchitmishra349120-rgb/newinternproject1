from app.routes.auth_routes import auth_bp
from app.routes.admin_routes import admin_bp
from app.routes.customer_routes import customer_bp
from app.routes.banking_routes import banking_bp
from app.routes.services_routes import services_bp
from app.routes.beneficiary_routes import beneficiary_bp
from app.routes.branch_routes import branch_bp
